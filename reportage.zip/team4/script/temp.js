function openNewPage(imageNum)
{
  var clickSrc = "rep04_03_0"+(imageNum) + "_articles.html";
  window.open(clickSrc);
}
