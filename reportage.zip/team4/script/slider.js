function getPosition(img, imageNum)
{
  setInterval(function(){
    console.log(imageNum);
    console.log(img.style.left);
  }, 3000);
}
